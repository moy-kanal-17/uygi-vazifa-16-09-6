for i in range(1,1099999999000,100):
  print(i)