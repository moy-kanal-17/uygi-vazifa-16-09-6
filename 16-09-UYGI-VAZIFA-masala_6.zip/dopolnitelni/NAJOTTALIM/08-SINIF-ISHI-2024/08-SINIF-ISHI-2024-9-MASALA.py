import colorama
cod= colorama.Fore.RED
back= colorama.Back.BLACK
n = int(input('\033[32;40mkotaligini kiriting...'))
for i in range(n):
    if i == 0 or i == n - 1:
        print(cod+back,"$ " * n)
    else:
        print(" $" + " " * (2 * n - 3) + "$")
