def my_range(*args):
    start = 0
    stop = 0
    step = 1

    if len(args) == 1:
        stop = args[0]
    elif len(args) == 2:
        start = args[0]
        stop = args[1]
    elif len(args) == 3:
        start = args[0]
        stop = args[1]
        step = args[2]
    else:
        print("Qiymatlar noto'g'ri kiritilgan!")
        return []
    lst = []
    while start <= stop:
        lst.append(start)
        start += step
    return lst
c = input('Raqamlarni kiriting (masalan: 1,10 yoki 1,10,2): ').split(',')
c = [int(x) for x in c]
print(my_range(*c))
