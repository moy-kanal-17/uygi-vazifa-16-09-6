juft=[]
yd=[]
toq=[]
sonn=[]
ishlatovchi=int(input("qancha son kiritmoqchisiz: "))
i=0
for i in range(ishlatovchi):
    print(i,")son", end=" ")
    son=int(input())
    if son%2==0:
        juft.append(son)
    elif son%2==1:
        toq.append(son)

print('juft',juft)
print('toq',toq)