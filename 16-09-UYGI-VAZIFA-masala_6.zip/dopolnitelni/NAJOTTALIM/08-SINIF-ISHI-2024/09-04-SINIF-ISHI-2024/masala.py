def func(**qiymatlar):
    print(qiymatlar["yosh"], qiymatlar["ism"], qiymatlar["yonalish"])


func(ism="Ali", yosh=19, guruh="N88", yonalish="Foundation")
#2
def func(n):
    if n == 1:
        return 1
    return n + func(n-1)

print(func(10))
#3
func= lambda a, b: a+b-2

print(func(10))