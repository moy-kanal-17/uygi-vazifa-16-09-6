ti=('ii ',)
ii = (44 , True, 'good', 'banana', 3.34,'apple')
if 'apple' in ii:
    print('bor')
else:
    print('yoq')
for i in ii:
    print(i)
print(ii)
ti=ii + ti
print(ti)
print('tugadiiiiiiiiiiiii')
a,c, *b=ii
print(a,c,b)