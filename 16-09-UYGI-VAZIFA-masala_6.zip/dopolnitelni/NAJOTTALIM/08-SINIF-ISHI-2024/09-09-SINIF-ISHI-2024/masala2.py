def katta(dicti):
    for key in dicti:
        dicti[key] = dicti[key].upper()
    return dicti

d = {
    "Ism": "Ali",
    "Familya": "Kamolov",
    "Manzil": "Angren shahri"
}
o = katta(d)
print(o)
