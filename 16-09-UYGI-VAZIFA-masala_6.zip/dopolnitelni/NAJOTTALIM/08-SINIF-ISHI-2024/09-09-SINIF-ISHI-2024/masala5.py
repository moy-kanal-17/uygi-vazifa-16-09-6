# ages = [14, 19, 22, 13, 45, 32]
#
#
# def func(x):
#     if x > 18:
#         return True
#     else:
#         return False
#
#
# res = filter(func, ages)
#
# print(list(res))
#2
ages = [14, 19, 22, 13, 45, 32]


def func(x):
    return x * 2


res = map(func, ages)

print(list(res))
