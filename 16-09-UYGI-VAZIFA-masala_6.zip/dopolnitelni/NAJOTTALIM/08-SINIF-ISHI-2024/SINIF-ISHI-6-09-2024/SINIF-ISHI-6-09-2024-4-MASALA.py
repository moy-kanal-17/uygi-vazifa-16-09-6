st = {
    "Samandar": 18,
    "Muzaffar": 19,
    "Xojiakbar": 16,
    "Islom": 20,
    "Asomiddin": 14,
    "Sobitjon": 17,
    "Shoxruh": 20
}
for name, age in st.items():
    if age >=18:
        print(name, age, end=",")