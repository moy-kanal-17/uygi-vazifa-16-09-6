login = {
    "jeymsBond": "agent007",
    "tony_stark": "ironman101",
    "piterParker": "spider.12.12",
    "sherlok": "sher.l04"}
username = input("Username kiriting: ")
password = input("Parol kiriting: ")
if username in login:
    print("Welcome " + username + "!")
    if login[username] == password:
        print("Hisobga kirdingiz")
    else:
        print("Parol noto'g'ri")
else:
    print("Bunday foydalanuvchi mavjud emas")
