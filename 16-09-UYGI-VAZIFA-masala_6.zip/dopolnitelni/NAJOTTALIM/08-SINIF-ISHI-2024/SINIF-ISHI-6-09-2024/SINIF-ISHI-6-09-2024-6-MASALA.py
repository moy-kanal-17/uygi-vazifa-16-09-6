set1 = {17,10, 20, 30, 40, 50}
set2 = {17,30, 40, 50, 60, 70}
set1.intersection_update(set2)
print(set1)
