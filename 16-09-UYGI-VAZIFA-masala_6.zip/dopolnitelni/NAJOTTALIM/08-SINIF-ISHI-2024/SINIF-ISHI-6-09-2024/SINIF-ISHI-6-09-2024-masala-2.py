set1={2,3,4,5,6}
set2={4,5,6,7,8,9}
set4={}
set5={}
set6={}
set4=set1.difference(set2)
set5=set2.difference(set1)
print(set4,set5)
c=0
for i in set4:
    print(i)
    c=i+c
for i in set5:
    print(i)
    c=i+c
set4.update(set5)
print(f'{c}= = Setlarning umumiy bo’lmagan elementlari yig’indisi')