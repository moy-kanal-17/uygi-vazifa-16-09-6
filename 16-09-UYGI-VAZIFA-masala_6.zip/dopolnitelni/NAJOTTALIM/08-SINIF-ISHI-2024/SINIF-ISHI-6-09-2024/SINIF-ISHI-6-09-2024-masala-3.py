set1={100, 20, 45, 80, 70, 50}
set2={30, 55, 70, 60, 32, 100}
i=0
for i in set1:
    if i <=60:
        print('ochirildi!')
    else:
        print(i)
print(set1)