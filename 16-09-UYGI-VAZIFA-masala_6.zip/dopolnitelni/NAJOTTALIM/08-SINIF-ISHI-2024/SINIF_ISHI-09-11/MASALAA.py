listt=[]
sa=int
def autio(listt):
    for i in listt:
        if i==',':
            listt.remove(i)
        elif i==' ':
            listt.remove(i)
        elif i== "'":
            listt.remove(i)
    return listt
si=input('kiriting')
listt.append(si)
print(autio(listt))