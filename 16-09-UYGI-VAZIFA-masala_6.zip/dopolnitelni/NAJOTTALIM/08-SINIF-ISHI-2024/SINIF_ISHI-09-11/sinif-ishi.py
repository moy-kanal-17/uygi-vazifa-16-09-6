import random
print('son man oylab toptim ! u 1 dan 100 gacha ! ')
def ishllash():
    try:
        sonn=int(input("kiriting"))
    except:
        print("kiritgan soningiz notog'ri!")
    else:
        if sonn>100:
            print('jinimisiz) etimku 100 gacha dep !')
        if son==sonn:
            print(f"son tog'ri ! !! bu son= {son} edi")
        elif sonn>son:
            print(f"yoq !, bu son kichkinaroq)")
            ishllash()
        elif sonn<son:
            print(f"yoq !, bu son kataroq)")
            ishllash()

print('man son oylab topaman siz uni topasiz !')
son=random.randint(1,100)
print(son)
ishllash()
