print("yoshingizni")
yil=int(input("yoshi:"))
tugilgan=2005-yil
print("tugilgan yiliz=",tugilgan)