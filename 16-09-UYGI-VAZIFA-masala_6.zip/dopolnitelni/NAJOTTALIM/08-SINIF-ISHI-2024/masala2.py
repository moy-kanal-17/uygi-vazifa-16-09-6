f = float(input("Fahrenheit darajasini kiriting: "))
ce = (5/9) * (f - 32)
print(f"Selsiy darajasi: ",f)