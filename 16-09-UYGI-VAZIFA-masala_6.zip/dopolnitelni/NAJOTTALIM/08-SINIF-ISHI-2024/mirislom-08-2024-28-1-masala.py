print("son kiriting... \n uch honali!!")
aa=int(input("kiriting!"))
c=aa//100%10
d=aa%100//10
k=aa%100%10
print(aa//100%10)
print(aa%100//10)
print(aa%100%10)
print("yeg'indi= ")
print(c+k+d)