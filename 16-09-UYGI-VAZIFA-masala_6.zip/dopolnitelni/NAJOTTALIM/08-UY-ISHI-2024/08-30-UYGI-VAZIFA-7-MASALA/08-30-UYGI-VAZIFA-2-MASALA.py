c=0
i=0
print('n =?')
n=int(input())
i=n
while i>=1:
    if i%2==0:
        print(i,end=' ')
        c=c+i
    i = i - 1
print("yeg'indi -= ..",c)