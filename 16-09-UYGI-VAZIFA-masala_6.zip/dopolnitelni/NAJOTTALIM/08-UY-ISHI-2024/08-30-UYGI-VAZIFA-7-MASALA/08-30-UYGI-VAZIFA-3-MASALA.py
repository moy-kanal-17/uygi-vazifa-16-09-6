son = int(input("son =? "))
ra = []
while son > 0:
    ra.insert(0, son % 10)
    son = son // 10
for i in ra:
   print(ra)