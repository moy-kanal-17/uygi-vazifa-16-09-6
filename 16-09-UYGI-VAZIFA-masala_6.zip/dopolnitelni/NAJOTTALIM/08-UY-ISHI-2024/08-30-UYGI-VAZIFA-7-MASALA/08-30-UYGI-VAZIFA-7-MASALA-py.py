n = int(input("UCHBURCHAK KOTALIGI: "))
for i in range(1, n + 1):
    print(' ' * (n - i), end='')
    print('* ' * i)
