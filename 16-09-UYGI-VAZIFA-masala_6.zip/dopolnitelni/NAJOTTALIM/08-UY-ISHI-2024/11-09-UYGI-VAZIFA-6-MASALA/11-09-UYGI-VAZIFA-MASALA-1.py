from collections import Counter
def ff(s):
    ch = Counter(s)
    return dict(ch)
ii = input('Enter a string: ')
result = ff(ii)
print(result)