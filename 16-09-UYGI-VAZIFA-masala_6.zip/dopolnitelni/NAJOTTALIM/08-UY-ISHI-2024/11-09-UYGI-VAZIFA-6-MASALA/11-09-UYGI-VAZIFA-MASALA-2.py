def co(lst):
    lst2 = []
    for item in lst:
        try:
            lst2.append(int(item))
        except ValueError:
            pass
    return lst2
lst = ["Salom", "123", "56", "Python", "Try", "90", "Except"]
lst2 = co(lst)
print(lst2)
