import math
def pr(lst):
    for item in lst:
        if type(item) == int or type(item) == float:
            print(f"{item} -> {math.isqrt(item)}")
lst = [16, "Pip", False, {}, 25, 49, 144, 'Modul']
pr(lst)
