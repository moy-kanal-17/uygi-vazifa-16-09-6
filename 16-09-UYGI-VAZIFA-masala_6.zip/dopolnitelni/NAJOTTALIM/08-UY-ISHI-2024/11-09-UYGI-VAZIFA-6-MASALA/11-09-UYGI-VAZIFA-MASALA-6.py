from googletrans import Translator
def mai(lsst):
    tra = Translator()
    tarjimadict = {}
    for i in lsst:
        if isinstance(i, str):
            try:
                tarjima = tra.translate(i, src='uz', dest='en').text
                tarjimadict[i] = tarjima
            except Exception as e:
                print(f"Tarjima paytida xatolik: {e}")
    return tarjimadict
lsst = ['salom', 12, 'dastur', True, 'yordam', 'kitob', 3.14]
natija = mai(lsst)
print(natija)
