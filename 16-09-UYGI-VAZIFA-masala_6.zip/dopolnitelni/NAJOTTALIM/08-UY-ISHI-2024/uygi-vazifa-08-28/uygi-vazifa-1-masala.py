print("a=?")
a=int(input())
print(a%100//10)
print(a%100%10)