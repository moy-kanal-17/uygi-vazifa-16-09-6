print("a=?")
a=int(input())
c=a%100//10
d=a%100%10
print(c,'+',d,'=',d+c)