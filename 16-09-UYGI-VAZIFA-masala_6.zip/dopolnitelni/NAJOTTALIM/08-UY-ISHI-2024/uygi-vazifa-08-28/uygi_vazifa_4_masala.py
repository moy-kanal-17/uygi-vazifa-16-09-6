print("a=?")
a=int(input())
c=a%100//10
d=a%100%10
l=a//100%100
print(l,"+",c,'+',d,'=',d+c+l)